[
    {
        "Key": "_RS_Normal1",
        "Category": "_RS_Custom",
        "Styles": {
            "LEVEL0": {
                "NormalStyle": {
                    "FontColor": "Text 1 15",
                    "Background": "Background 1 0",
                    "BorderRadiusString": "0px 0px 0px 0px"
                },
                "HoverStyle": {
                    "Background": "Accent 1 80 128",
                    "BorderRadiusString": "2px 2px 2px 2px"
                },
                "SelectedStyle": {
                    "FontColor": "Accent 1 0",
                    "Background": "Accent 1 80",
                    "BorderRadiusString": "2px 2px 2px 2px",
                    "Bold": true
                }
            },
            "LEVEL1": {
                "NormalStyle": {
                    "FontColor": "Text 1 15",
                    "Background": "Background 1 0",
                    "BorderRadiusString": "0px 0px 0px 0px"
                },
                "HoverStyle": {
                    "Background": "Accent 1 80 128",
                    "BorderRadiusString": "2px 2px 2px 2px"
                },
                "SelectedStyle": {
                    "FontColor": "Accent 1 0",
                    "Background": "Accent 1 80",
                    "BorderRadiusString": "2px 2px 2px 2px",
                    "Bold": true
                }
            },
            "LEVEL2": {
                "NormalStyle": {
                    "FontColor": "Text 1 15",
                    "Background": "Background 1 0",
                    "BorderRadiusString": "0px 0px 0px 0px"
                },
                "HoverStyle": {
                    "Background": "#7ED0E9FF",
                    "BorderRadiusString": "2px 2px 2px 2px"
                },
                "SelectedStyle": {
                    "FontColor": "Accent 1 0",
                    "Background": "Accent 1 80",
                    "BorderRadiusString": "2px 2px 2px 2px",
                    "Bold": true
                }
            },
            "LEVEL3": {
                "NormalStyle": {
                    "FontColor": "Text 1 15",
                    "Background": "Background 1 0",
                    "BorderRadiusString": "0px 0px 0px 0px"
                },
                "HoverStyle": {
                    "Background": "Accent 1 80 128",
                    "BorderRadiusString": "2px 2px 2px 2px"
                },
                "SelectedStyle": {
                    "FontColor": "Accent 1 0",
                    "Background": "Accent 1 80",
                    "BorderRadiusString": "2px 2px 2px 2px",
                    "Bold": true
                }
            }
        }
    },
    {
        "Key": "_RS_Normal2",
        "Category": "_RS_Custom",
        "Styles": {
            "LEVEL0": {
                "NormalStyle": {
                    "FontColor": "Background 1 -15",
                    "Background": "Text 1 15",
                    "BorderRadiusString": "0px 0px 0px 0px"
                },
                "HoverStyle": {
                    "Background": "#FF323739",
                    "BorderRadiusString": "2px 2px 2px 2px"
                },
                "SelectedStyle": {
                    "FontColor": "Background 1 0",
                    "Background": "#FF3D4245",
                    "BorderRadiusString": "2px 2px 2px 2px",
                    "Bold": true
                }
            },
            "LEVEL1": {
                "NormalStyle": {
                    "FontColor": "Background 1 -15",
                    "Background": "Text 1 15",
                    "BorderRadiusString": "0px 0px 0px 0px"
                },
                "HoverStyle": {
                    "Background": "#FF323739",
                    "BorderRadiusString": "2px 2px 2px 2px"
                },
                "SelectedStyle": {
                    "FontColor": "Background 1 0",
                    "Background": "#FF3D4245",
                    "BorderRadiusString": "2px 2px 2px 2px",
                    "Bold": true
                }
            },
            "LEVEL2": {
                "NormalStyle": {
                    "FontColor": "Background 1 -15",
                    "Background": "Text 1 15",
                    "BorderRadiusString": "0px 0px 0px 0px"
                },
                "HoverStyle": {
                    "Background": "#FF323739",
                    "BorderRadiusString": "2px 2px 2px 2px"
                },
                "SelectedStyle": {
                    "FontColor": "Background 1 0",
                    "Background": "#FF3D4245",
                    "BorderRadiusString": "2px 2px 2px 2px",
                    "Bold": true
                }
            },
            "LEVEL3": {
                "NormalStyle": {
                    "FontColor": "Background 1 -15",
                    "Background": "Text 1 15",
                    "BorderRadiusString": "0px 0px 0px 0px"
                },
                "HoverStyle": {
                    "Background": "#FF323739",
                    "BorderRadiusString": "2px 2px 2px 2px"
                },
                "SelectedStyle": {
                    "FontColor": "Background 1 0",
                    "Background": "#FF3D4245",
                    "BorderRadiusString": "2px 2px 2px 2px",
                    "Bold": true
                }
            }
        }
    }
];
//# sourceMappingURL=ForguncyMenu.js.map