[
    {
        "Key": "_RS_Forecolor_Style1",
        "Category": "_RS_Forecolor",
        "StyleTemplateFashionScope": "1",
        "Styles": {
            "Tree": {
                "NormalStyle": {
                    "FontColor": "Text 1"
                },
                "HoverStyle": {
                    "FontColor": "Accent 1 50"
                },
                "SelectedStyle": {
                    "FontColor": "Accent 1"
                },
                "Transition": "0.15s"
            }
        }
    },
    {
        "Key": "_RS_Forecolor_Style2",
        "Category": "_RS_Forecolor",
        "StyleTemplateFashionScope": "1",
        "Styles": {
            "Tree": {
                "NormalStyle": {
                    "FontColor": "Text 1"
                },
                "HoverStyle": {
                    "FontColor": "Accent 2 50"
                },
                "SelectedStyle": {
                    "FontColor": "Accent 2"
                },
                "Transition": "0.15s"
            }
        }
    },
    {
        "Key": "_RS_Forecolor_Style3",
        "Category": "_RS_Forecolor",
        "StyleTemplateFashionScope": "1",
        "Styles": {
            "Tree": {
                "NormalStyle": {
                    "FontColor": "Text 1"
                },
                "HoverStyle": {
                    "FontColor": "Accent 3 50"
                },
                "SelectedStyle": {
                    "FontColor": "Accent 3"
                },
                "Transition": "0.15s"
            }
        }
    },
    {
        "Key": "_RS_Forecolor_Style4",
        "Category": "_RS_Forecolor",
        "StyleTemplateFashionScope": "1",
        "Styles": {
            "Tree": {
                "NormalStyle": {
                    "FontColor": "Text 1"
                },
                "HoverStyle": {
                    "FontColor": "Accent 4 50"
                },
                "SelectedStyle": {
                    "FontColor": "Accent 4"
                },
                "Transition": "0.15s"
            }
        }
    },
    {
        "Key": "_RS_Forecolor_Style5",
        "Category": "_RS_Forecolor",
        "StyleTemplateFashionScope": "1",
        "Styles": {
            "Tree": {
                "NormalStyle": {
                    "FontColor": "Text 1"
                },
                "HoverStyle": {
                    "FontColor": "Accent 5 50"
                },
                "SelectedStyle": {
                    "FontColor": "Accent 5"
                },
                "Transition": "0.15s"
            }
        }
    },
    {
        "Key": "_RS_Forecolor_Style6",
        "Category": "_RS_Forecolor",
        "StyleTemplateFashionScope": "1",
        "Styles": {
            "Tree": {
                "NormalStyle": {
                    "FontColor": "Text 1"
                },
                "HoverStyle": {
                    "FontColor": "Accent 6 50"
                },
                "SelectedStyle": {
                    "FontColor": "Accent 6"
                },
                "Transition": "0.15s"
            }
        }
    },
    {
        "Key": "_RS_Normal_Style1",
        "Category": "_RS_Normal",
        "StyleTemplateFashionScope": "1",
        "Styles": {
            "Tree": {
                "NormalStyle": {
                    "FontColor": "Text 1",
                    "BorderRadiusString": "4px 4px 4px 4px"
                },
                "HoverStyle": {
                    "Background": "Accent 1 80"
                },
                "SelectedStyle": {
                    "FontColor": "Background 1",
                    "Background": "Accent 1"
                },
                "Transition": "0.15s"
            }
        }
    },
    {
        "Key": "_RS_Normal_Style2",
        "Category": "_RS_Normal",
        "StyleTemplateFashionScope": "1",
        "Styles": {
            "Tree": {
                "NormalStyle": {
                    "FontColor": "Text 1",
                    "BorderRadiusString": "4px 4px 4px 4px"
                },
                "HoverStyle": {
                    "Background": "Accent 2 80"
                },
                "SelectedStyle": {
                    "FontColor": "Background 1",
                    "Background": "Accent 2"
                },
                "Transition": "0.15s"
            }
        }
    },
    {
        "Key": "_RS_Normal_Style3",
        "Category": "_RS_Normal",
        "StyleTemplateFashionScope": "1",
        "Styles": {
            "Tree": {
                "NormalStyle": {
                    "FontColor": "Text 1",
                    "BorderRadiusString": "4px 4px 4px 4px"
                },
                "HoverStyle": {
                    "Background": "Accent 3 80"
                },
                "SelectedStyle": {
                    "FontColor": "Background 1",
                    "Background": "Accent 3"
                },
                "Transition": "0.15s"
            }
        }
    },
    {
        "Key": "_RS_Normal_Style4",
        "Category": "_RS_Normal",
        "StyleTemplateFashionScope": "1",
        "Styles": {
            "Tree": {
                "NormalStyle": {
                    "FontColor": "Text 1",
                    "BorderRadiusString": "4px 4px 4px 4px"
                },
                "HoverStyle": {
                    "Background": "Accent 4 80"
                },
                "SelectedStyle": {
                    "FontColor": "Background 1",
                    "Background": "Accent 4"
                },
                "Transition": "0.15s"
            }
        }
    },
    {
        "Key": "_RS_Normal_Style5",
        "Category": "_RS_Normal",
        "StyleTemplateFashionScope": "1",
        "Styles": {
            "Tree": {
                "NormalStyle": {
                    "FontColor": "Text 1",
                    "BorderRadiusString": "4px 4px 4px 4px"
                },
                "HoverStyle": {
                    "Background": "Accent 5 80"
                },
                "SelectedStyle": {
                    "FontColor": "Background 1",
                    "Background": "Accent 5"
                },
                "Transition": "0.15s"
            }
        }
    },
    {
        "Key": "_RS_Normal_Style6",
        "Category": "_RS_Normal",
        "StyleTemplateFashionScope": "1",
        "Styles": {
            "Tree": {
                "NormalStyle": {
                    "FontColor": "Text 1",
                    "BorderRadiusString": "4px 4px 4px 4px"
                },
                "HoverStyle": {
                    "Background": "Accent 6 80"
                },
                "SelectedStyle": {
                    "FontColor": "Background 1",
                    "Background": "Accent 6"
                },
                "Transition": "0.15s"
            }
        }
    },
    {
        "Key": "_RS_RoundCorner_Style1",
        "Category": "_RS_RoundCorner",
        "StyleTemplateFashionScope": "1",
        "Styles": {
            "Tree": {
                "NormalStyle": {
                    "FontColor": "Text 1",
                    "BorderRadiusString": "20px 20px 20px 20px"
                },
                "HoverStyle": {
                    "Background": "Accent 1 80"
                },
                "SelectedStyle": {
                    "FontColor": "Background 1",
                    "Background": "Accent 1"
                },
                "Transition": "0.15s"
            }
        }
    },
    {
        "Key": "_RS_RoundCorner_Style2",
        "Category": "_RS_RoundCorner",
        "StyleTemplateFashionScope": "1",
        "Styles": {
            "Tree": {
                "NormalStyle": {
                    "FontColor": "Text 1",
                    "BorderRadiusString": "20px 20px 20px 20px"
                },
                "HoverStyle": {
                    "Background": "Accent 2 80"
                },
                "SelectedStyle": {
                    "FontColor": "Background 1",
                    "Background": "Accent 2"
                },
                "Transition": "0.15s"
            }
        }
    },
    {
        "Key": "_RS_RoundCorner_Style3",
        "Category": "_RS_RoundCorner",
        "StyleTemplateFashionScope": "1",
        "Styles": {
            "Tree": {
                "NormalStyle": {
                    "FontColor": "Text 1",
                    "BorderRadiusString": "20px 20px 20px 20px"
                },
                "HoverStyle": {
                    "Background": "Accent 3 80"
                },
                "SelectedStyle": {
                    "FontColor": "Background 1",
                    "Background": "Accent 3"
                },
                "Transition": "0.15s"
            }
        }
    },
    {
        "Key": "_RS_RoundCorner_Style4",
        "Category": "_RS_RoundCorner",
        "StyleTemplateFashionScope": "1",
        "Styles": {
            "Tree": {
                "NormalStyle": {
                    "FontColor": "Text 1",
                    "BorderRadiusString": "20px 20px 20px 20px"
                },
                "HoverStyle": {
                    "Background": "Accent 4 80"
                },
                "SelectedStyle": {
                    "FontColor": "Background 1",
                    "Background": "Accent 4"
                },
                "Transition": "0.15s"
            }
        }
    },
    {
        "Key": "_RS_RoundCorner_Style5",
        "Category": "_RS_RoundCorner",
        "StyleTemplateFashionScope": "1",
        "Styles": {
            "Tree": {
                "NormalStyle": {
                    "FontColor": "Text 1",
                    "BorderRadiusString": "20px 20px 20px 20px"
                },
                "HoverStyle": {
                    "Background": "Accent 5 80"
                },
                "SelectedStyle": {
                    "FontColor": "Background 1",
                    "Background": "Accent 5"
                },
                "Transition": "0.15s"
            }
        }
    },
    {
        "Key": "_RS_RoundCorner_Style6",
        "Category": "_RS_RoundCorner",
        "StyleTemplateFashionScope": "1",
        "Styles": {
            "Tree": {
                "NormalStyle": {
                    "FontColor": "Text 1",
                    "BorderRadiusString": "20px 20px 20px 20px"
                },
                "HoverStyle": {
                    "Background": "Accent 6 80"
                },
                "SelectedStyle": {
                    "FontColor": "Background 1",
                    "Background": "Accent 6"
                },
                "Transition": "0.15s"
            }
        }
    },
    {
        "Key": "_RS_NewFashionStyle1",
        "Category": "_RS_RecommendStyle",
        "StyleTemplateFashionScope": "2",
        "Styles": {
            "Tree": {
                "NormalStyle": {
                    "FontColor": "Text 1 15",
                    "BorderString": "1px solid Background_1_0",
                    "BorderRadiusString": "3px 3px 3px 3px"
                },
                "HoverStyle": {
                    "FontColor": "Accent 1 40",
                    "BorderString": "1px solid Accent_1_40",
                    "BorderRadiusString": "3px 3px 3px 3px"
                },
                "SelectedStyle": {
                    "FontColor": "Accent 1 0",
                    "BorderString": "1px solid Accent_1_0",
                    "InsideHorizontalBorderString": "",
                    "InsideVerticalBorderString": "",
                    "BorderRadiusString": "3px 3px 3px 3px"
                },
                "Transition": "0.15s"
            }
        }
    },
    {
        "Key": "_RS_NewFashionStyle2",
        "Category": "_RS_RecommendStyle",
        "StyleTemplateFashionScope": "2",
        "Styles": {
            "Tree": {
                "NormalStyle": {
                    "FontColor": "Text 1 15",
                    "BorderRadiusString": "4px 4px 4px 4px"
                },
                "HoverStyle": {
                    "Background": "Accent 1 80 127"
                },
                "SelectedStyle": {
                    "FontColor": "Accent 1 0",
                    "Background": "Accent 1 80"
                },
                "Transition": "0.15s"
            }
        }
    },
];
